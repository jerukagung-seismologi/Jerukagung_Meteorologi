# METEOFIELD — Taman Alat Meteorologi 3D

Aplikasi edukasi interaktif untuk menjelajahi taman alat meteorologi berbasis **Three.js**, **WebGL**, dan **Vite**. Semua instrumen utama dibangun secara prosedural dari geometri Three.js; proyek tidak membutuhkan file model 3D eksternal.

## Fitur

- Lingkungan lapangan observasi terbuka bernuansa tropis dengan rumput, pagar, jalur akses, cahaya siang, awan, dan bayangan.
- Sembilan model instrumen: sangkar meteorologi, penakar hujan observatorium, AWS, anemometer + wind vane, Campbell–Stokes, panci penguapan, plot suhu tanah, pyranometer, dan barometer digital.
- Orbit, zoom, dan pan dengan `OrbitControls`.
- Pemilihan instrumen melalui raycasting, hover label, fokus kamera, preset isometrik/atas/depan/samping, dan reset kamera.
- Panel direktori dengan pencarian, kategori, dan kontrol tampil/sembunyi.
- Label instrumen, grid bantu, dan mode layar penuh.
- Antarmuka dan materi penjelasan dalam Bahasa Indonesia.
- Layout responsif untuk desktop, tablet, dan ponsel.

## Persyaratan

- Node.js 20.19+ atau 22.12+ disarankan (sesuai persyaratan rilis Vite 7).
- npm 10+.
- Browser modern dengan dukungan WebGL 2.

## Instalasi dan menjalankan

```bash
# 1. Masuk ke folder proyek
cd met-garden

# 2. Instal dependensi
npm install

# 3. Jalankan server pengembangan
npm run dev
```

Buka URL lokal yang ditampilkan Vite (umumnya `http://localhost:5173`).

Untuk membuat build produksi:

```bash
npm run build
npm run preview
```

Hasil build berada di folder `dist/`.

## Kontrol

| Aksi | Kontrol |
|---|---|
| Rotasi kamera | Klik kiri + drag |
| Pan kamera | Klik kanan + drag (atau gesture pan OrbitControls) |
| Zoom | Scroll mouse / pinch |
| Pilih instrumen | Klik model 3D atau item direktori |
| Fokus instrumen | Klik ikon fokus pada panel informasi |
| Ganti kamera | ISO, ATAS, DEPAN, SAMPING |
| Kembalikan tampilan awal | RESET |
| Tampilkan/sembunyikan | Ikon mata pada direktori |
| Label dan grid | Tombol pada viewport atau panel tampilan |
| Layar penuh | Tombol di pojok kanan atas |

## Struktur proyek

```text
met-garden/
├── index.html
├── package.json
├── README.md
└── src/
    ├── main.js
    ├── components/
    │   ├── MeteorologicalGarden.js
    │   ├── StevensonScreen.js
    │   ├── RainGauge.js
    │   ├── AWS.js
    │   ├── Anemometer.js
    │   ├── CampbellStokes.js
    │   ├── EvaporationPan.js
    │   ├── SoilTemperaturePlot.js
    │   ├── Pyranometer.js
    │   ├── Barometer.js
    │   └── primitives.js
    ├── data/
    │   └── instruments.js
    ├── systems/
    │   ├── LightingSystem.js
    │   ├── CameraSystem.js
    │   └── InteractionSystem.js
    └── styles/
        └── main.css
```

## Catatan ilmiah dan batasan model

Visualisasi ini ditujukan untuk **edukasi instrumentasi dan tata ruang secara konseptual**. Ini bukan gambar kerja konstruksi, desain stasiun yang telah disurvei, sertifikasi WMO/BMKG, ataupun pengganti SOP pengamatan. Ukuran lapangan, dimensi model instrumen, jarak antarperangkat, dan beberapa detail pemasangan adalah **ilustratif dan dapat diubah**. Jangan memakai geometri model sebagai acuan pembangunan tanpa pemeriksaan standar dan kondisi tapak.

Sejumlah prinsip telah dimasukkan pada model dan keterangannya:

- Sangkar meteorologi diberi kisi-kisi ventilasi ganda, lapisan atap, dan representasi termometer internal.
- AWS memisahkan representasi sensor angin, suhu/kelembapan, radiasi, pencatat data, dan catu daya.
- Pedoman WMO untuk pengamatan meteorologi permukaan menyebut pemasangan sensor suhu dan kelembapan pada kisaran 1,25–2,0 m di atas permukaan, serta exposure instrumen angin pada 10 m di atas medan terbuka. Kesesuaian aktual tetap bergantung pada jenis stasiun dan standar yang diterapkan.
- Tata letak taman alat perlu mempertimbangkan exposure, arah mata angin, gangguan antarperangkat, jalur kabel, drainase, dan konfigurasi stasiun setempat.
- Tidak ada observasi cuaca langsung atau pembacaan sensor nyata. Angka pengukuran tidak disajikan, sehingga model tidak menyamar sebagai sistem monitoring real-time.

### Referensi teknis awal

1. BMKG, **Peraturan Kepala BMKG Nomor 12 Tahun 2022 tentang Standardisasi Stasiun Klimatologi**, Lampiran II — Denah Taman Alat dan keterangan posisi perangkat. [Dokumen JDIH BMKG](https://jdih.bmkg.go.id/storage/common/dokumen/perkano.12tahun2022.pdf)
2. WMO, **Manual on the WMO Integrated Global Observing System (WIGOS)** — persyaratan tinggi sensor suhu/kelembapan dan exposure instrumen angin. [Dokumen WMO/Manual WIGOS](https://iklim.bmkg.go.id/publikasi-klimat/ftp/regulasi-brosur/Manual%20on%20WIGOS%20Annex%20VIII%201160-2019_en.pdf)
3. WMO, **Guide to Instruments and Methods of Observation (WMO-No. 8), 2024 edition**. [Halaman resmi WMO](https://community.wmo.int/site/knowledge-hub/programmes-and-initiatives/instruments-and-methods-of-observation-programme/guide-instruments-and-methods-observation-wmo-no-8-0)
4. Stasiun Klimatologi Jawa Tengah, **Mengenal Aloptama** — ringkasan instrumen pengamatan klimatologi. [BMKG Staklim Jateng](https://staklim-jateng.bmkg.go.id/aboutaloptama.php)

## Kustomisasi

- Data deskripsi, kategori, posisi, dan offset kamera berada di `src/data/instruments.js`.
- Geometri tiap instrumen berada pada modul terpisah di `src/components/`.
- Ukuran lapangan, pagar, rumput, dan lingkungan dapat diubah di `src/components/MeteorologicalGarden.js`.
- Pencahayaan dan preset kamera dapat disesuaikan di `src/systems/`.
- Desain antarmuka berada di `src/styles/main.css`.

## Catatan performa

Rumput dibuat dengan `InstancedMesh` untuk mengurangi draw call. Detail instrumen menggunakan geometri sederhana-menengah yang dapat diperluas. Shadow map menggunakan resolusi 2048; pada perangkat kelas rendah, matikan bayangan atau kurangi jumlah instans rumput untuk meningkatkan performa.
