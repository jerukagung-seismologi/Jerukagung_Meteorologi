import * as THREE from 'three';
export function setupLighting(scene) {
  const hemi=new THREE.HemisphereLight('#dbeeff','#64765a',2.1); scene.add(hemi);
  const sun=new THREE.DirectionalLight('#fff1d4',3.2); sun.position.set(-24,38,18); sun.castShadow=true;
  sun.shadow.mapSize.set(2048,2048); sun.shadow.camera.left=-42; sun.shadow.camera.right=42; sun.shadow.camera.top=42; sun.shadow.camera.bottom=-42; sun.shadow.camera.near=0.5; sun.shadow.camera.far=100; sun.shadow.bias=-0.00016; sun.shadow.normalBias=0.025; sun.shadow.radius=4;
  scene.add(sun);
  const fill=new THREE.DirectionalLight('#bfddec',0.8); fill.position.set(28,16,-24); scene.add(fill);
  return {sun,hemi,fill};
}
