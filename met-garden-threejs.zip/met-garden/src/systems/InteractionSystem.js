import * as THREE from 'three';
export function createInteractionSystem({camera,scene,renderer,objects,onSelect,onHover}) {
  const raycaster=new THREE.Raycaster(); raycaster.params.Line.threshold=0.2;
  const pointer=new THREE.Vector2(); let hovered=null, selected=null;
  const highlightMaterial=new THREE.MeshBasicMaterial({color:'#ffe08a',wireframe:true,transparent:true,opacity:0.22,depthWrite:false});
  const highlights=new Map();
  function getId(object){let current=object;while(current){if(current.userData?.instrumentId)return current.userData.instrumentId;current=current.parent;}return null;}
  function point(event){const rect=renderer.domElement.getBoundingClientRect();pointer.x=((event.clientX-rect.left)/rect.width)*2-1;pointer.y=-((event.clientY-rect.top)/rect.height)*2+1;}
  function setHover(id){if(hovered===id)return; clearHighlight(); hovered=id; if(id)applyHighlight(id); renderer.domElement.style.cursor=id?'pointer':'grab'; onHover(id);}
  function click(event){point(event);raycaster.setFromCamera(pointer,camera);const hits=raycaster.intersectObjects([...objects.values()],true);const id=hits.map(h=>getId(h.object)).find(Boolean);if(id){selected=id;onSelect(id);}}
  function move(event){point(event);raycaster.setFromCamera(pointer,camera);const hits=raycaster.intersectObjects([...objects.values()],true);const id=hits.map(h=>getId(h.object)).find(Boolean);setHover(id);}
  function leave(){setHover(null);}
  renderer.domElement.addEventListener('click',click); renderer.domElement.addEventListener('pointermove',move); renderer.domElement.addEventListener('pointerleave',leave);
  function setSelected(id){selected=id;}
  function dispose(){renderer.domElement.removeEventListener('click',click);renderer.domElement.removeEventListener('pointermove',move);renderer.domElement.removeEventListener('pointerleave',leave);clearHighlight();}
  return {setSelected,get selected(){return selected;},get hovered(){return hovered;},dispose};
}
