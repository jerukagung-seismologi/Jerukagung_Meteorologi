import * as THREE from 'three';
export function createCameraSystem(camera, controls) {
  const presets={
    isometric:{position:new THREE.Vector3(43,36,48),target:new THREE.Vector3(0,0,0)},
    top:{position:new THREE.Vector3(0,78,0.01),target:new THREE.Vector3(0,0,0)},
    front:{position:new THREE.Vector3(0,19,64),target:new THREE.Vector3(0,2,0)},
    side:{position:new THREE.Vector3(70,20,0),target:new THREE.Vector3(0,2,0)}
  };
  let transition=null;
  function moveTo(position,target,duration=900) {
    transition={start:performance.now(),duration,fromPosition:camera.position.clone(),toPosition:position.clone(),fromTarget:controls.target.clone(),toTarget:target.clone()};
  }
  function preset(name){const p=presets[name];if(p)moveTo(p.position,p.target);}
  function focus(object, offset) {
    const box=new THREE.Box3().setFromObject(object), center=box.getCenter(new THREE.Vector3());
    const size=box.getSize(new THREE.Vector3());
    const max=Math.max(size.x,size.y,size.z,1);
    const direction=new THREE.Vector3(...offset).normalize();
    const dist=Math.max(5.5,max*2.4);
    moveTo(center.clone().add(direction.multiplyScalar(dist)),center,850);
  }
  function update(now) {
    if(!transition)return;
    const t=Math.min(1,(now-transition.start)/transition.duration); const e=t<0.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
    camera.position.lerpVectors(transition.fromPosition,transition.toPosition,e);
    controls.target.lerpVectors(transition.fromTarget,transition.toTarget,e);
    if(t>=1)transition=null;
  }
  return {preset,focus,moveTo,update,presets};
}
