import * as THREE from 'three';
import { materials, mat, box, cylinder, rod, torus, createInstrumentRoot, tagInstrument, addFooting, addLabel } from './primitives.js';
export function createEvaporationPan(data) {
  const g=createInstrumentRoot(data.id,data.shortName,data.position); addFooting(g,1.1);
  const steel=mat('#b3bdc0',0.3,0.8), rim=mat('#d5dcdd',0.24,0.82);
  cylinder(g,0.96,0.96,0.3,[0,0.6,0],steel,72);
  cylinder(g,0.91,0.91,0.23,[0,0.73,0],materials.water,72);
  torus(g,0.96,0.045,[0,0.77,0],rim,64,12);
  // Platform supports.
  for(let i=0;i<4;i++){
    const a=i*Math.PI/2+Math.PI/4;
    box(g,[0.14,0.26,0.14],[Math.cos(a)*0.68,0.34,Math.sin(a)*0.68],materials.darkMetal);
  }
  box(g,[1.82,0.08,1.82],[0,0.17,0],materials.whiteMetal);
  // Still well and hook gauge bridge.
  cylinder(g,0.11,0.11,0.25,[0.52,0.88,0.36],steel,24);
  cylinder(g,0.08,0.08,0.18,[0.52,1.02,0.36],materials.darkMetal,24);
  rod(g,[-0.72,1.38,0.0],[0.72,1.38,0.0],0.035,materials.darkMetal);
  rod(g,[0.52,1.38,0],[0.52,0.94,0],0.022,materials.brass);
  rod(g,[0.52,0.95,0],[0.52,0.88,0],0.012,materials.brass);
  box(g,[0.2,0.04,0.12],[-0.73,1.38,0],materials.whiteMetal);
  addLabel(g,data.shortName); tagInstrument(g,data.id); return g;
}
