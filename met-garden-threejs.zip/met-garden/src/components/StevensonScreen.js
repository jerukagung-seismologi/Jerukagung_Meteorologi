import * as THREE from 'three';
import { materials, mat, box, cylinder, rod, sphere, createInstrumentRoot, tagInstrument, addFooting, addLabel } from './primitives.js';

export function createStevensonScreen(data) {
  const g = createInstrumentRoot(data.id, data.shortName, data.position);
  addFooting(g, 0.72);
  const white = materials.white, trim = mat('#d7ddd8', 0.76), dark = mat('#45504e', 0.8);
  // Four independent legs and bracing.
  for (const x of [-0.58, 0.58]) for (const z of [-0.48, 0.48]) {
    box(g, [0.095, 1.3, 0.095], [x, 0.79, z], white);
    box(g, [0.13, 0.055, 0.13], [x, 0.16, z], trim);
  }
  rod(g, [-0.58,0.82,-0.48], [0.58,0.82,0.48], 0.028, trim);
  rod(g, [-0.58,0.82,0.48], [0.58,0.82,-0.48], 0.028, trim);
  // Inner floor and rear wall.
  box(g, [1.22,0.07,1.04], [0,1.45,0], white);
  box(g, [1.16,0.07,0.055], [0,1.93,-0.49], white);
  // Double-louvred side walls: slats are separate, slanted boards.
  for (let layer = 0; layer < 2; layer++) {
    const inset = layer === 0 ? 0.02 : 0.15;
    for (let side of [-1,1]) {
      for (let i = 0; i < 9; i++) {
        const y = 1.58 + i * 0.09;
        const slat = box(g, [1.17,0.045,0.055], [0,y,side * (0.49 - inset)], white);
        slat.rotation.z = -0.16;
        slat.rotation.y = layer === 0 ? 0 : Math.PI;
      }
    }
    for (let side of [-1,1]) {
      for (let i = 0; i < 9; i++) {
        const y = 1.58 + i * 0.09;
        const slat = box(g, [0.055,0.045,0.96], [side * (0.58 - inset),y,0], white);
        slat.rotation.z = side * 0.16;
      }
    }
  }
  // Open door, making the internal thermometers visible.
  const door = new THREE.Group(); door.position.set(-0.58, 1.9, 0.5); door.rotation.y = -0.75; g.add(door);
  for (let i = 0; i < 8; i++) {
    const slat = box(door, [0.04,0.045,0.96], [0,(i-3.5)*0.09,0], white);
    slat.rotation.x = 0.12;
  }
  box(door, [0.055,0.86,0.055], [0,0,0.46], trim);
  // Double roof layers with ventilation gap.
  box(g, [1.62,0.09,1.45], [0,2.43,0], white);
  box(g, [1.42,0.06,1.28], [0,2.57,0], trim);
  for (const x of [-0.62,0.62]) rod(g,[x,2.45,-0.57],[x,2.55,-0.57],0.035,white);
  // Thermometers on the inner rear rail.
  const positions = [-0.34,-0.12,0.12,0.34];
  positions.forEach((x,i) => {
    const h = i === 2 ? 0.55 : 0.7;
    box(g, [0.065,h,0.045], [x,1.82,-0.22], trim);
    box(g, [0.025,h*0.74,0.018], [x,1.82,-0.194], dark);
    sphere(g,0.035,[x,1.82-h/2+0.04,-0.19], i===1 ? mat('#4e9cc2') : mat('#c56b58'),12,8);
    box(g,[0.11,0.025,0.025],[x,2.2,-0.18],white);
  });
  box(g,[0.8,0.045,0.055],[0,1.5,-0.2],trim);
  addLabel(g, data.shortName);
  tagInstrument(g, data.id);
  return g;
}
