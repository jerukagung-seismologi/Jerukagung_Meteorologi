import * as THREE from 'three';
import { materials, mat, box, cylinder, rod, sphere, torus, createInstrumentRoot, tagInstrument, addFooting, addLabel } from './primitives.js';
export function createCampbellStokes(data) {
  const g=createInstrumentRoot(data.id,data.shortName,data.position); addFooting(g,0.65);
  box(g,[1.1,0.12,0.9],[0,0.25,0],materials.whiteMetal);
  cylinder(g,0.12,0.16,0.2,[0,0.39,0],materials.darkMetal,24);
  // Cast brass curved cradle, with glass sphere in its center.
  const arc=new THREE.Mesh(new THREE.TorusGeometry(0.68,0.045,12,64,Math.PI*1.4),materials.brass);
  arc.rotation.set(Math.PI/2,0,Math.PI*0.3); arc.position.set(0,1.02,0); arc.castShadow=true; g.add(arc);
  const glass=sphere(g,0.43,[0,1.02,0],materials.glass,48,32); glass.material=materials.glass;
  torus(g,0.48,0.025,[0,0.99,0],materials.brass,48,8,[Math.PI/2,0,0]);
  // Pias holder curves behind the sphere.
  const holder=box(g,[0.82,0.045,0.15],[0,1.47,-0.44],materials.darkMetal); holder.rotation.x=-0.35;
  const card=box(g,[0.75,0.018,0.12],[0,1.5,-0.42],mat('#b9a17a',0.88)); card.rotation.x=-0.35;
  for(let i=0;i<9;i++) box(g,[0.012,0.004,0.11],[-0.34+i*0.085,1.515,-0.42],materials.red);
  rod(g,[-0.45,0.28,0],[0,1.02,0],0.035,materials.brass);
  rod(g,[0.45,0.28,0],[0,1.02,0],0.035,materials.brass);
  addLabel(g,data.shortName); tagInstrument(g,data.id); return g;
}
