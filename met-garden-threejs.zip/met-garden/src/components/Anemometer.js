import * as THREE from 'three';
import { materials, mat, box, cylinder, rod, sphere, createInstrumentRoot, tagInstrument, addFooting, addLabel } from './primitives.js';
export function createAnemometer(data) {
  const g=createInstrumentRoot(data.id,data.shortName,data.position); addFooting(g,0.56);
  cylinder(g,0.1,0.14,0.5,[0,0.3,0],materials.darkMetal,20);
  cylinder(g,0.035,0.055,9.25,[0,5.1,0],materials.galvanized,20);
  for(let i=0;i<3;i++){
    const a=i*Math.PI*2/3;
    const y=9.72;
    rod(g,[0,y,0],[Math.cos(a)*0.52,y,Math.sin(a)*0.52],0.026,materials.whiteMetal,8);
    const cup=sphere(g,0.15,[Math.cos(a)*0.55,y+0.025,Math.sin(a)*0.55],materials.white,20,14); cup.scale.set(1,0.78,0.95);
  }
  cylinder(g,0.04,0.04,0.15,[0,9.79,0],materials.red,16);
  // Vane assembly below rotor.
  rod(g,[0,8.95,0],[0,9.56,0],0.025,materials.darkMetal);
  rod(g,[-0.55,9.32,0],[0.55,9.32,0],0.018,materials.whiteMetal);
  const arrow=new THREE.Mesh(new THREE.ConeGeometry(0.12,0.3,4),materials.red); arrow.position.set(0.64,9.32,0); arrow.rotation.z=-Math.PI/2; g.add(arrow);
  box(g,[0.48,0.055,0.045],[-0.3,9.32,0],materials.white);
  for(let i=0;i<3;i++){ const a=i*2.094; rod(g,[0,8.4,0],[Math.cos(a)*1.25,0.18,Math.sin(a)*1.25],0.012,materials.whiteMetal,6); }
  addLabel(g,data.shortName); tagInstrument(g,data.id); return g;
}
