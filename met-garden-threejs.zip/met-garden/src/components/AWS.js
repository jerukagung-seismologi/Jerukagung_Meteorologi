import * as THREE from 'three';
import { materials, mat, box, cylinder, rod, sphere, torus, createInstrumentRoot, tagInstrument, addFooting, addLabel } from './primitives.js';

function makeCupRotor(parent, y) {
  cylinder(parent,0.035,0.035,0.16,[0,y,0],materials.darkMetal,16);
  for (let i=0;i<3;i++) {
    const a=i*Math.PI*2/3;
    const armEnd=[Math.cos(a)*0.52,y,Math.sin(a)*0.52];
    rod(parent,[0,y,0],armEnd,0.025,materials.whiteMetal,8);
    const cup=sphere(parent,0.16,[Math.cos(a)*0.53,y+0.03,Math.sin(a)*0.53],materials.white,20,14);
    cup.scale.set(1,0.72,0.95);
  }
  cylinder(parent,0.045,0.045,0.1,[0,y+0.12,0],materials.red,16);
}
function makeVane(parent,y) {
  rod(parent,[0,y,0],[0,y+0.65,0],0.025,materials.darkMetal);
  rod(parent,[-0.52,y+0.5,0],[0.54,y+0.5,0],0.02,materials.whiteMetal);
  const arrow=new THREE.Mesh(new THREE.ConeGeometry(0.13,0.36,4),materials.red); arrow.position.set(0.62,y+0.5,0); arrow.rotation.z=-Math.PI/2; parent.add(arrow);
  const tail=box(parent,[0.5,0.06,0.05],[-0.33,y+0.5,0],materials.white); tail.rotation.z=0.02;
}
export function createAWS(data) {
  const g=createInstrumentRoot(data.id,data.shortName,data.position); addFooting(g,0.72);
  const mast=materials.galvanized;
  cylinder(g,0.1,0.15,0.5,[0,0.38,0],materials.darkMetal,24);
  cylinder(g,0.045,0.045,9.5,[0,5.25,0],mast,24);
  for (let y of [0.35,2.0,4.1,6.6,9.8,10.1]) cylinder(g,0.065,0.065,0.09,[0,y,0],materials.darkMetal,16);
  // Guy wires and anchors.
  for(let i=0;i<3;i++){
    const a=i*Math.PI*2/3+0.4;
    rod(g,[0.04,8.8,0],[Math.cos(a)*1.85,0.18,Math.sin(a)*1.85],0.012,materials.whiteMetal,6);
    cylinder(g,0.11,0.13,0.23,[Math.cos(a)*1.85,0.12,Math.sin(a)*1.85],materials.darkMetal,12);
  }
  // Wind sensors at mast top.
  rod(g,[0,9.7,0],[0.78,9.7,0],0.025,materials.whiteMetal);
  const cupBase=new THREE.Group(); cupBase.position.set(0,9.72,0); g.add(cupBase); makeCupRotor(cupBase,0.1);
  const vaneBase=new THREE.Group(); vaneBase.position.set(0,8.95,0); g.add(vaneBase); makeVane(vaneBase,0.5);
  // Temperature / humidity sensor shield, low arm at approx 1.5m in model representation.
  rod(g,[0,1.65,0],[0.88,1.65,0],0.025,materials.whiteMetal);
  cylinder(g,0.14,0.14,0.52,[0.88,1.45,0],materials.white,24);
  for(let i=0;i<9;i++){
    const ring=torus(g,0.14,0.014,[0.88,1.25+i*0.05,0],materials.whiteMetal,20,6);
  }
  // Radiation sensor on a short horizontal arm.
  rod(g,[0,3.0,0],[-1.05,3.0,0],0.025,materials.whiteMetal);
  cylinder(g,0.22,0.22,0.09,[-1.05,3.11,0],materials.whiteMetal,32);
  sphere(g,0.16,[-1.05,3.18,0],materials.glass,24,16);
  // Pressure and data logger enclosure.
  box(g,[0.85,0.95,0.38],[0.55,2.3,0],materials.white);
  box(g,[0.66,0.59,0.035],[0.55,2.34,0.21],materials.darkMetal);
  box(g,[0.54,0.35,0.02],[0.55,2.4,0.235],mat('#294e63',0.34));
  box(g,[0.16,0.08,0.025],[0.55,2.15,0.235],materials.green);
  for(let i=0;i<4;i++) cylinder(g,0.018,0.018,0.04,[0.32+i*0.15,2.05,0.22],materials.brass,8);
  // Solar panel angled towards sky.
  const panel=box(g,[1.1,0.07,0.72],[-0.8,2.5,0.28],mat('#244c67',0.3,0.42)); panel.rotation.z=-0.28;
  for(let i=0;i<5;i++) rod(g,[-1.28+i*0.22,2.47,-0.08],[-1.28+i*0.22,2.47,0.62],0.008,materials.galvanized,6);
  rod(g,[-0.8,2.5,0.3],[-0.8,1.98,0.3],0.025,materials.galvanized);
  // Conduit.
  rod(g,[0.9,2.3,0.08],[0.25,0.2,0.08],0.026,materials.darkMetal,8);
  addLabel(g,data.shortName); tagInstrument(g,data.id); return g;
}
