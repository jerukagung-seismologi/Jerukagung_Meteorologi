import * as THREE from 'three';
import { CSS2DObject } from 'three/addons/renderers/CSS2DRenderer.js';

export const mat = (color, roughness = 0.72, metalness = 0, extra = {}) => new THREE.MeshStandardMaterial({ color, roughness, metalness, ...extra });
export const materials = {
  white: mat('#f2f3ed', 0.82),
  whiteMetal: mat('#e7ecef', 0.36, 0.72),
  galvanized: mat('#98a8b3', 0.33, 0.82),
  darkMetal: mat('#273746', 0.48, 0.72),
  black: mat('#18242b', 0.62, 0.25),
  rubber: mat('#30393c', 0.9),
  wood: mat('#ad9b73', 0.9),
  green: mat('#4e7551', 0.95),
  red: mat('#d35a43', 0.48),
  blue: mat('#4e93bd', 0.42, 0.15),
  glass: new THREE.MeshPhysicalMaterial({ color: '#dff3f3', roughness: 0.06, metalness: 0, transmission: 0.94, thickness: 0.28, transparent: true, opacity: 0.55, ior: 1.48 }),
  water: new THREE.MeshPhysicalMaterial({ color: '#77bcd0', roughness: 0.12, metalness: 0.12, transmission: 0.15, transparent: true, opacity: 0.86, clearcoat: 1, clearcoatRoughness: 0.08 }),
  soil: mat('#796047', 1),
  soilDark: mat('#4e3b2d', 1),
  brass: mat('#b58b4b', 0.3, 0.78),
};

export function addMesh(parent, geometry, material, position = [0,0,0], name = '') {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(...position);
  if (name) mesh.name = name;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}
export function box(parent, size, position, material, name) { return addMesh(parent, new THREE.BoxGeometry(...size), material, position, name); }
export function cylinder(parent, radiusTop, radiusBottom, height, position, material, radialSegments = 24, name) { return addMesh(parent, new THREE.CylinderGeometry(radiusTop, radiusBottom, height, radialSegments), material, position, name); }
export function sphere(parent, radius, position, material, widthSegments = 24, heightSegments = 16, name) { return addMesh(parent, new THREE.SphereGeometry(radius, widthSegments, heightSegments), material, position, name); }
export function rod(parent, start, end, radius, material, radialSegments = 10) {
  const a = new THREE.Vector3(...start), b = new THREE.Vector3(...end);
  const direction = new THREE.Vector3().subVectors(b, a);
  const mesh = addMesh(parent, new THREE.CylinderGeometry(radius, radius, direction.length(), radialSegments), material, a.clone().add(b).multiplyScalar(0.5).toArray());
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0), direction.normalize());
  return mesh;
}
export function torus(parent, radius, tube, position, material, radialSegments = 40, tubularSegments = 10, rotation = [Math.PI/2,0,0]) {
  const mesh = addMesh(parent, new THREE.TorusGeometry(radius, tube, radialSegments, tubularSegments), material, position);
  mesh.rotation.set(...rotation);
  return mesh;
}
export function createInstrumentRoot(id, label, position) {
  const group = new THREE.Group();
  group.name = label;
  group.position.set(...position);
  group.userData.instrumentId = id;
  group.userData.label = label;
  return group;
}
export function tagInstrument(group, id) {
  group.traverse(obj => {
    if (obj.isMesh) {
      obj.userData.instrumentId = id;
      obj.castShadow = true;
      obj.receiveShadow = true;
    }
  });
}
export function addFooting(parent, radius = 0.48) {
  cylinder(parent, radius, radius, 0.12, [0,0.06,0], mat('#8c9692', 0.96), 32);
  cylinder(parent, radius * 0.72, radius * 0.72, 0.015, [0,0.125,0], mat('#aeb5ad', 0.85), 32);
}
export function addLabel(parent, label, className = 'instrument-label') {
  const div = document.createElement('div');
  div.className = className;
  div.textContent = label;
  const labelObject = new CSS2DObject(div);
  labelObject.position.set(0, 1.25, 0);
  parent.add(labelObject);
  return labelObject;
}
