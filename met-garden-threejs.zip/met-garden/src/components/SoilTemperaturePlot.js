import * as THREE from 'three';
import { CSS2DObject } from 'three/addons/renderers/CSS2DRenderer.js';
import { materials, mat, box, cylinder, rod, sphere, createInstrumentRoot, tagInstrument, addFooting, addLabel } from './primitives.js';
export function createSoilTemperaturePlot(data) {
  const g=createInstrumentRoot(data.id,data.shortName,data.position);
  const soil=materials.soil;
  box(g,[3.0,0.18,2.5],[0,0.0,0],soil);
  box(g,[3.1,0.09,0.07],[0,0.12,-1.22],materials.wood);
  box(g,[3.1,0.09,0.07],[0,0.12,1.22],materials.wood);
  box(g,[0.07,0.09,2.5],[-1.52,0.12,0],materials.wood);
  box(g,[0.07,0.09,2.5],[1.52,0.12,0],materials.wood);
  // Four probe points and stylized depth wells.
  const depths=[0.35,0.65,0.95,1.25];
  depths.forEach((y,i)=>{
    const x=-1.0+i*0.66, z=0;
    cylinder(g,0.055,0.07,0.11,[x,0.16,z],materials.darkMetal,16);
    cylinder(g,0.025,0.025,0.58,[x,-0.14,z],materials.galvanized,12);
    sphere(g,0.055,[x,-0.39,z],i%2?materials.red:materials.blue,12,8);
    box(g,[0.23,0.08,0.14],[x,0.24,0.35],materials.white);
    // Compact readable depth tag beside each probe.
    const depthTag=document.createElement('div'); depthTag.className='depth-tag'; depthTag.textContent=['5 cm','10 cm','20 cm','50 cm'][i];
    const depthObject=new CSS2DObject(depthTag); depthObject.position.set(x,0.31,0.58); g.add(depthObject);
    for(let j=0;j<2+i;j++) box(g,[0.012,0.04,0.012],[x-0.06+j*0.04,0.29,0.43],materials.darkMetal);
  });
  // Cut-away soil cross-section with a small exposed profile edge.
  box(g,[0.08,0.38,1.9],[1.56,-0.13,0],materials.soilDark);
  for(let i=0;i<5;i++) rod(g,[1.61,-0.28+i*0.12,-0.82],[1.61,-0.28+i*0.12,0.82],0.012,materials.wood,6);
  // Ground cover tufts around measurement patch.
  const grassMat=mat('#5e8d4d',1);
  for(let i=0;i<16;i++){
    const x=-1.3+(i%8)*0.37, z=(i<8?-0.92:0.92);
    const blade=new THREE.Mesh(new THREE.ConeGeometry(0.055,0.28,4),grassMat); blade.position.set(x,0.22,z); blade.castShadow=true; g.add(blade);
  }
  addLabel(g,data.shortName); tagInstrument(g,data.id); return g;
}
