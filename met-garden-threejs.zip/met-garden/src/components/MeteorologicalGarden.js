import * as THREE from 'three';
import { instruments } from '../data/instruments.js';
import { materials, mat, box, cylinder, rod, sphere } from './primitives.js';
import { createStevensonScreen } from './StevensonScreen.js';
import { createRainGauge } from './RainGauge.js';
import { createAWS } from './AWS.js';
import { createAnemometer } from './Anemometer.js';
import { createCampbellStokes } from './CampbellStokes.js';
import { createEvaporationPan } from './EvaporationPan.js';
import { createSoilTemperaturePlot } from './SoilTemperaturePlot.js';
import { createPyranometer } from './Pyranometer.js';
import { createBarometer } from './Barometer.js';

const builders = {
  stevenson: createStevensonScreen,
  raingauge: createRainGauge,
  aws: createAWS,
  wind: createAnemometer,
  campbell: createCampbellStokes,
  evaporation: createEvaporationPan,
  soil: createSoilTemperaturePlot,
  pyranometer: createPyranometer,
  barometer: createBarometer
};

function seededRandom(seed=13) { let x=seed; return () => { x=(x*1664525+1013904223)>>>0; return x/4294967296; }; }
function makeGrassTexture() {
  const size=512, canvas=document.createElement('canvas'); canvas.width=canvas.height=size;
  const ctx=canvas.getContext('2d');
  const image=ctx.createImageData(size,size); const rand=seededRandom(43);
  for(let i=0;i<image.data.length;i+=4){
    const n=(rand()-0.5)*26;
    image.data[i]=78+n; image.data[i+1]=116+n; image.data[i+2]=64+n*0.6; image.data[i+3]=255;
  }
  ctx.putImageData(image,0,0);
  for(let i=0;i<5200;i++){
    const x=rand()*size,y=rand()*size,r=rand()*2+0.4;
    ctx.fillStyle=rand()>0.52?'rgba(36,73,37,.18)':'rgba(173,174,92,.12)';
    ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();
  }
  const texture=new THREE.CanvasTexture(canvas); texture.wrapS=texture.wrapT=THREE.RepeatWrapping; texture.repeat.set(3,2); texture.colorSpace=THREE.SRGBColorSpace; texture.anisotropy=8; return texture;
}
function createGrassBlades(scene) {
  const geometry=new THREE.BufferGeometry();
  const vertices=new Float32Array([-0.035,0,0, 0.035,0,0, 0.005,0.22,0, 0,-0.0,-0.026, 0,0,0.026, -0.008,0.19,0.01]);
  const indices=[0,1,2,3,4,5]; geometry.setAttribute('position',new THREE.BufferAttribute(vertices,3)); geometry.setIndex(indices); geometry.computeVertexNormals();
  const material=new THREE.MeshStandardMaterial({color:'#8cab65',roughness:1,side:THREE.DoubleSide});
  const count=9500, mesh=new THREE.InstancedMesh(geometry,material,count); mesh.receiveShadow=true;
  const dummy=new THREE.Object3D(), rand=seededRandom(77);
  for(let i=0;i<count;i++){
    const x=(rand()-0.5)*59,z=(rand()-0.5)*37;
    dummy.position.set(x,-0.08,z); dummy.rotation.y=rand()*Math.PI; dummy.scale.setScalar(0.55+rand()*0.75); dummy.updateMatrix(); mesh.setMatrixAt(i,dummy.matrix);
  }
  mesh.instanceMatrix.needsUpdate=true; mesh.userData.decorative=true; scene.add(mesh); return mesh;
}
function createCloud(scene, x,y,z, scale=1) {
  const group=new THREE.Group(); group.position.set(x,y,z); group.scale.setScalar(scale); scene.add(group);
  const material=new THREE.MeshStandardMaterial({color:'#ffffff',roughness:1,transparent:true,opacity:0.92});
  const puffs=[[-1,0,0,1.25],[0,0.25,0,1.5],[1,0.06,0,1.15],[0.45,-0.16,0.45,0.92],[-0.55,-0.12,0.5,0.9]];
  puffs.forEach(([a,b,c,r])=>{const m=new THREE.Mesh(new THREE.SphereGeometry(r,18,12),material);m.position.set(a,b,c);m.scale.y=0.55;m.castShadow=false;group.add(m);});
  return group;
}
function createFence(scene) {
  const fence=new THREE.Group(), x=30.5,z=19.5, y=0.95; const rail=mat('#d6dedf',0.34,0.74), post=mat('#a7b4b8',0.38,0.76);
  const sides=[{a:[-x,0,-z],b:[x,0,-z],count:16},{a:[-x,0,z],b:[x,0,z],count:16},{a:[-x,0,-z],b:[-x,0,z],count:11},{a:[x,0,-z],b:[x,0,z],count:11}];
  sides.forEach(s=>{
    const A=new THREE.Vector3(...s.a),B=new THREE.Vector3(...s.b);
    for(let i=0;i<=s.count;i++){
      const p=A.clone().lerp(B,i/s.count); cylinder(fence,0.075,0.075,1.9,[p.x,0.95,p.z],post,12);
      cylinder(fence,0.11,0.11,0.1,[p.x,1.92,p.z],rail,12);
    }
    rod(fence,[...s.a.slice(0,1),0.7,s.a[2]],[...s.b.slice(0,1),0.7,s.b[2]],0.035,rail,8);
    rod(fence,[...s.a.slice(0,1),1.65,s.a[2]],[...s.b.slice(0,1),1.65,s.b[2]],0.035,rail,8);
  });
  // Front gate kept visually modest.
  const gate=new THREE.Group(); gate.position.set(0,0,19.5); fence.add(gate);
  box(gate,[2.6,1.75,0.08],[0,0.9,0],rail);
  for(let i=0;i<7;i++) box(gate,[0.06,1.55,0.11],[-1.05+i*0.35,0.88,0],post);
  scene.add(fence); return fence;
}
function createGround(scene) {
  const grassMat=new THREE.MeshStandardMaterial({map:makeGrassTexture(),color:'#ffffff',roughness:1});
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(64,42,1,1),grassMat); ground.rotation.x=-Math.PI/2; ground.position.y=-0.16; ground.receiveShadow=true; scene.add(ground);
  // Fine boundary curb and an unobtrusive access path.
  const curb=mat('#b9c3bf',0.92);
  box(scene,[64,0.12,0.34],[0,-0.07,-21],curb);
  box(scene,[64,0.12,0.34],[0,-0.07,21],curb);
  box(scene,[0.34,0.12,42],[-32,-0.07,0],curb);
  box(scene,[0.34,0.12,42],[32,-0.07,0],curb);
  const path=box(scene,[1.1,0.045,11],[0,-0.08,14.5],mat('#c1c6bd',0.96)); path.receiveShadow=true;
  for(let i=0;i<12;i++) box(scene,[1.1,0.018,0.025],[0,-0.05,9.3+i*0.9],mat('#a7b1a8',1));
}
function createBackground(scene) {
  scene.background=new THREE.Color('#9fc5da');
  scene.fog=new THREE.Fog('#a8c9d8',58,140);
  // Distant silhouettes: low horizon vegetation outside the fenced observation plot.
  const distant=new THREE.Group();
  const green=mat('#527d67',1), trunk=mat('#655947',1);
  for(let i=0;i<22;i++){
    const x=-65+i*6.1; const h=2.3+(i%5)*0.45;
    cylinder(distant,0.12,0.2,h,[x,h/2,-34],trunk,8);
    sphere(distant,1.8,[x,h+0.75,-34],green,12,8).scale.set(1.4,0.75,0.85);
  }
  scene.add(distant);
  createCloud(scene,-28,24,-48,2.1); createCloud(scene,4,29,-54,2.5); createCloud(scene,38,25,-42,1.8); createCloud(scene,-5,31,28,1.55);
}

export function createMeteorologicalGarden(scene, labelLayer) {
  createBackground(scene); createGround(scene); createGrassBlades(scene); createFence(scene);
  // Subtle metrology yard marker / north indication.
  const north=new THREE.Group(); north.position.set(26,0,14); scene.add(north);
  cylinder(north,0.25,0.25,0.08,[0,0.04,0],mat('#e2e5df',0.85),24);
  const arrow=new THREE.Mesh(new THREE.ConeGeometry(0.18,0.56,4),mat('#d45a45',0.5)); arrow.position.set(0,0.52,0); north.add(arrow);
  const objects=new Map(); const labels=new Map();
  instruments.forEach(data=>{
    const group=builders[data.id](data); scene.add(group); objects.set(data.id,group);
    // Each instrument builder adds its own CSS2D label; lift it above the object's bounds.
    const label=group.children.find(child => child.isCSS2DObject);
    if (label) {
      const bounds = new THREE.Box3().setFromObject(group);
      label.position.set(0, Math.max(1.4, bounds.max.y - group.position.y + 0.55), 0);
      labels.set(data.id,label);
    }
  });
  return { objects, labels };
}
