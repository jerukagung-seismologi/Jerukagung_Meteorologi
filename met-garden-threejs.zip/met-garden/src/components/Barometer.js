import * as THREE from 'three';
import { materials, mat, box, cylinder, rod, sphere, torus, createInstrumentRoot, tagInstrument, addFooting, addLabel } from './primitives.js';
export function createBarometer(data) {
  const g=createInstrumentRoot(data.id,data.shortName,data.position); addFooting(g,0.55);
  box(g,[0.95,1.65,0.56],[0,1.0,0],materials.white);
  box(g,[0.83,1.5,0.06],[0,1.0,0.3],materials.whiteMetal);
  box(g,[0.68,0.48,0.06],[0,1.42,0.34],materials.darkMetal);
  box(g,[0.58,0.34,0.025],[0,1.44,0.38],mat('#193c50',0.36));
  // Screen segments and digits as physical strokes, not data.
  for(let i=0;i<6;i++) box(g,[0.045,0.09,0.012],[-0.22+i*0.09,1.46,0.4],materials.green);
  box(g,[0.16,0.05,0.02],[0,1.08,0.37],materials.galvanized);
  for(let i=0;i<7;i++) box(g,[0.65,0.018,0.02],[0,0.88+i*0.045,0.34],materials.whiteMetal);
  for(let x of [-0.34,0.34]) cylinder(g,0.025,0.025,0.1,[x,0.1,0],materials.darkMetal,12);
  box(g,[0.12,0.13,0.12],[0.57,1.0,0],materials.darkMetal);
  addLabel(g,data.shortName); tagInstrument(g,data.id); return g;
}
