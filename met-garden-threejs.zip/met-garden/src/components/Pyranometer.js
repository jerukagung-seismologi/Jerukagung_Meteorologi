import * as THREE from 'three';
import { materials, mat, box, cylinder, rod, sphere, torus, createInstrumentRoot, tagInstrument, addFooting, addLabel } from './primitives.js';
export function createPyranometer(data) {
  const g=createInstrumentRoot(data.id,data.shortName,data.position); addFooting(g,0.55);
  cylinder(g,0.1,0.14,0.62,[0,0.39,0],materials.galvanized,24);
  box(g,[0.78,0.08,0.78],[0,0.77,0],materials.whiteMetal);
  cylinder(g,0.25,0.25,0.12,[0,0.87,0],materials.darkMetal,48);
  sphere(g,0.22,[0,1.0,0],materials.glass,32,20);
  cylinder(g,0.07,0.07,0.1,[0,0.91,0],materials.black,24);
  // Bubble level and cable port.
  cylinder(g,0.06,0.06,0.025,[0.28,0.82,0.26],materials.brass,16);
  sphere(g,0.025,[0.28,0.847,0.26],materials.glass,12,8);
  rod(g,[0.0,0.85,-0.25],[0.0,0.55,-0.55],0.02,materials.darkMetal);
  addLabel(g,data.shortName); tagInstrument(g,data.id); return g;
}
