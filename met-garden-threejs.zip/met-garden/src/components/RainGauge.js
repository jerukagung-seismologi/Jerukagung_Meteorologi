import * as THREE from 'three';
import { materials, mat, box, cylinder, torus, createInstrumentRoot, tagInstrument, addFooting, addLabel } from './primitives.js';
export function createRainGauge(data) {
  const g = createInstrumentRoot(data.id, data.shortName, data.position); addFooting(g,0.42);
  const metal = materials.galvanized, inner = mat('#6d7b81',0.35,0.62);
  cylinder(g,0.19,0.19,0.88,[0,0.67,0],metal,48);
  cylinder(g,0.167,0.167,0.78,[0,0.69,0],inner,48);
  const funnel = new THREE.Mesh(new THREE.CylinderGeometry(0.42,0.12,0.27,64,1,true),metal);
  funnel.position.y = 1.18; funnel.castShadow=true; funnel.receiveShadow=true; g.add(funnel);
  torus(g,0.42,0.027,[0,1.315,0],materials.whiteMetal,48,12);
  torus(g,0.128,0.018,[0,1.035,0],materials.darkMetal,32,8);
  // Funnel throat and inner receiver visible above body.
  cylinder(g,0.115,0.09,0.18,[0,1.005,0],inner,32);
  cylinder(g,0.105,0.105,0.39,[0,0.72,0],materials.water,32);
  box(g,[0.1,0.58,0.1],[0.29,0.35,0],materials.darkMetal);
  box(g,[0.1,0.58,0.1],[-0.29,0.35,0],materials.darkMetal);
  box(g,[0.1,0.1,0.72],[0,0.28,0],materials.whiteMetal);
  addLabel(g,data.shortName); tagInstrument(g,data.id); return g;
}
