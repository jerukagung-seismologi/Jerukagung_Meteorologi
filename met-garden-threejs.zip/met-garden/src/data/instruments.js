export const instruments = [
  {
    id: 'stevenson', name: 'Sangkar Meteorologi', shortName: 'Sangkar Meteo', category: 'manual', categoryLabel: 'MANUAL', subtitle: 'Pelindung instrumen suhu dan kelembapan udara', parameter: ['Suhu udara', 'Kelembapan relatif'],
    function: 'Melindungi termometer dan sensor higrometri dari radiasi matahari langsung serta presipitasi, sambil mempertahankan sirkulasi udara agar pengukuran mewakili kondisi udara lingkungan.',
    principle: 'Udara luar mengalir melalui kisi-kisi berlapis. Permukaan putih membantu memantulkan radiasi surya; ventilasi mengurangi pemanasan dan memungkinkan sensor merespons suhu serta kandungan uap air udara.',
    components: ['Dinding jalusi ganda', 'Atap pelindung dua lapis', 'Lantai berbilah / berventilasi', 'Termometer bola kering dan bola basah', 'Termometer maksimum dan minimum', 'Kaki penyangga dan pintu akses'],
    operation: 'Pengamat membaca termometer sesuai prosedur waktu pengamatan. Pada psikrometer konvensional, bola basah harus memiliki sumbu bersih dan terbasahi dengan benar. Pintu dibuka sesingkat mungkin agar kondisi internal tidak banyak berubah.',
    note: 'Model memperlihatkan kisi-kisi ganda dan susunan termometer secara konseptual. Orientasi pintu serta tinggi pemasangan harus mengikuti standar dan kondisi tapak setempat.', position: [-15, 0, -7], viewOffset: [4, 3, 5]
  },
  {
    id: 'raingauge', name: 'Penakar Hujan Observatorium', shortName: 'Ombrometer', category: 'manual', categoryLabel: 'MANUAL', subtitle: 'Penakar hujan manual tipe observatorium', parameter: ['Curah hujan'],
    function: 'Menampung air hujan pada luas mulut penakar yang diketahui sehingga kedalaman hujan dapat ditentukan dan dilaporkan dalam milimeter.',
    principle: 'Air masuk melalui corong ke dalam tabung penampung. Volume air yang terkumpul dibaca menggunakan gelas ukur berskala; luas penampang dan prosedur pembacaan menentukan konversi volume menjadi kedalaman hujan.',
    components: ['Mulut / bibir penakar', 'Corong pengumpul', 'Badan silinder logam', 'Tabung penampung bagian dalam', 'Dudukan atau fondasi rata'],
    operation: 'Air yang tertampung dipindahkan atau diukur sesuai desain alat pada waktu observasi. Pastikan corong bersih, alat tegak, dan tidak ada kebocoran atau hambatan pada inlet.',
    note: 'Representasi ini adalah penakar observatorium manual, bukan penakar Hellmann maupun tipping-bucket otomatis.', position: [-8, 0, -13], viewOffset: [3, 2, 4]
  },
  {
    id: 'aws', name: 'Automatic Weather Station', shortName: 'AWS', category: 'otomatis', categoryLabel: 'OTOMATIS', subtitle: 'Sistem pengamatan cuaca otomatis terintegrasi', parameter: ['Angin', 'Suhu dan kelembapan', 'Tekanan udara', 'Radiasi surya'],
    function: 'Mengukur beberapa unsur cuaca secara otomatis, menyimpan data pada pencatat data, serta mengirimkan hasil pengamatan ke sistem akuisisi atau telemetri.',
    principle: 'Transduser pada tiap sensor mengubah besaran fisis menjadi sinyal listrik atau digital. Pencatat data melakukan sampling, pemberian cap waktu, pemeriksaan dasar, penyimpanan, dan bila tersedia meneruskan data melalui jaringan komunikasi.',
    components: ['Mast dan lengan sensor', 'Sensor kecepatan / arah angin', 'Pelindung sensor suhu-kelembapan', 'Sensor tekanan dalam enclosure', 'Pyranometer', 'Data logger dan kotak instrumen', 'Panel surya dan kabel'],
    operation: 'Sensor harus dipasang pada ketinggian dan exposure yang sesuai dengan variabel yang diukur. Sistem memerlukan pemeriksaan catu daya, sinkronisasi waktu, komunikasi, kebersihan sensor, dan kalibrasi berkala.',
    note: 'Mast dan susunan sensor merupakan konfigurasi demonstrasi. Untuk pengamatan angin permukaan, WMO menetapkan exposure 10 m di atas medan terbuka; tinggi sensor suhu/kelembapan permukaan umumnya 1,25–2,0 m.', position: [12, 0, -13], viewOffset: [5, 4, 6]
  },
  {
    id: 'wind', name: 'Anemometer dan Wind Vane', shortName: 'Anemometer', category: 'manual', categoryLabel: 'MANUAL', subtitle: 'Pengukuran kecepatan dan arah angin', parameter: ['Kecepatan angin', 'Arah angin'],
    function: 'Mengamati gerak udara dekat permukaan. Anemometer mangkuk merespons kecepatan aliran, sedangkan wind vane sejajar dengan arah datangnya angin.',
    principle: 'Putaran mangkuk diteruskan menjadi pulsa atau hitungan putaran yang dikalibrasi terhadap kecepatan angin. Baling-baling arah berputar pada sumbu vertikal dan menunjukkan arah asal angin.',
    components: ['Mast vertikal', 'Tiga mangkuk anemometer', 'Poros dan lengan rotor', 'Wind vane / sirip arah', 'Bearing dan kabel sensor'],
    operation: 'Pastikan sensor bebas dari turbulensi lokal dan hambatan. Catat arah sebagai arah asal angin; pemeriksaan bearing, keseimbangan rotor, orientasi utara, dan ketinggian pemasangan penting untuk mutu data.',
    note: 'Model menampilkan konfigurasi mangkuk dan sirip arah pada mast. Tinggi referensi angin permukaan WMO adalah 10 m di atas medan terbuka.', position: [2, 0, -5], viewOffset: [4, 5, 5]
  },
  {
    id: 'campbell', name: 'Perekam Sinar Matahari Campbell–Stokes', shortName: 'Campbell–Stokes', category: 'lainnya', categoryLabel: 'RADIASI', subtitle: 'Pencatat lama penyinaran matahari', parameter: ['Durasi / lama penyinaran matahari'],
    function: 'Merekam durasi sinar matahari langsung yang cukup kuat untuk membakar jejak pada kartu pias khusus.',
    principle: 'Bola kaca memfokuskan sinar matahari ke kartu pias yang ditempatkan pada dudukan melengkung. Jejak terbakar pada kartu kemudian dibaca untuk menentukan lama penyinaran menurut prosedur instrumen.',
    components: ['Bola kaca pejal', 'Cangkang / dudukan logam', 'Mangkok penyangga', 'Dudukan kartu pias', 'Basis penyetel dan penanda lintang'],
    operation: 'Gunakan jenis kartu pias yang sesuai musim dan lintang, pasang pada dudukan yang benar, dan baca panjang jejak setelah periode pengamatan. Bola kaca harus bersih dan dudukan terarah serta rata.',
    note: 'Jejak bakar tidak disimulasikan sebagai data. Efektivitas alat bergantung pada posisi geografis, musim, dan pemilihan kartu pias.', position: [-15, 0, 7], viewOffset: [3, 3, 4]
  },
  {
    id: 'evaporation', name: 'Panci Penguapan (Open Pan)', shortName: 'Evaporation Pan', category: 'lainnya', categoryLabel: 'HIDROLOGI', subtitle: 'Estimasi evaporasi dari permukaan air terbuka', parameter: ['Penguapan / evaporasi'],
    function: 'Mengamati perubahan tinggi muka air pada panci terbuka sebagai indeks evaporasi dari permukaan air, dengan memperhatikan hujan dan faktor koreksi yang berlaku.',
    principle: 'Perubahan tinggi muka air dalam interval tertentu diukur menggunakan hook gauge atau alat ukur muka air. Neraca air harus memperhitungkan presipitasi dan penambahan atau pengeluaran air.',
    components: ['Panci logam bundar', 'Permukaan air', 'Dudukan / platform', 'Hook gauge atau sumur penenang', 'Papan ukur / titik referensi'],
    operation: 'Baca tinggi muka air pada waktu tetap, catat hujan, lakukan pengisian atau pengurasan sesuai prosedur, dan jaga panci bebas dari kebocoran serta kontaminan.',
    note: 'Dimensi panci dan faktor konversi tidak ditetapkan di visual ini karena berbeda menurut tipe alat dan prosedur operasional.', position: [14, 0, 5], viewOffset: [4, 3, 4]
  },
  {
    id: 'soil', name: 'Plot Pengamatan Suhu Tanah', shortName: 'Suhu Tanah', category: 'lainnya', categoryLabel: 'TANAH', subtitle: 'Profil suhu pada beberapa kedalaman tanah', parameter: ['Suhu tanah pada kedalaman tertentu'],
    function: 'Mengamati variasi suhu tanah secara vertikal dan temporal untuk kajian neraca energi permukaan, mikroklimat, dan pertukaran panas tanah–atmosfer.',
    principle: 'Termometer atau sensor suhu ditempatkan pada kedalaman yang ditentukan. Elemen sensor mencapai kesetimbangan termal dengan tanah di sekitarnya dan menghasilkan pembacaan suhu pada kedalaman tersebut.',
    components: ['Petak tanah khusus', 'Sensor / termometer tanah', 'Kabel sensor dan terminal', 'Titik pengukuran berbagai kedalaman', 'Penutup atau penanda titik'],
    operation: 'Jaga kontak termal sensor dengan tanah, hindari rongga udara saat pemasangan, dan catat kedalaman aktual. Gunakan titik yang konsisten untuk seri waktu serta dokumentasikan kondisi tutupan tanah.',
    note: 'Kedalaman 5, 10, 20, dan 50 cm pada model hanyalah contoh label demonstratif; kedalaman resmi mengikuti program pengamatan.', position: [-3, 0, 11], viewOffset: [4, 3, 5]
  },
  {
    id: 'pyranometer', name: 'Pyranometer', shortName: 'Pyranometer', category: 'otomatis', categoryLabel: 'RADIASI', subtitle: 'Sensor radiasi matahari global', parameter: ['Iradiasi surya global'],
    function: 'Mengukur radiasi gelombang pendek yang diterima dari seluruh hemisfer di atas bidang horizontal, umumnya dinyatakan dalam W/m².',
    principle: 'Pada pyranometer termopile, radiasi yang diserap permukaan hitam menghasilkan beda suhu terhadap referensi yang dikonversi menjadi tegangan sebanding dengan irradiansi. Model sensor lain dapat menggunakan prinsip fotodioda.',
    components: ['Kubah kaca / quartz', 'Elemen sensor', 'Rumah sensor', 'Waterpass / indikator level', 'Basis leveling dan kabel'],
    operation: 'Pasang pada bidang horizontal yang rata dan bebas bayangan. Bersihkan kubah, periksa level, lakukan pemeriksaan respons dan kalibrasi sesuai jadwal, serta dokumentasikan gangguan bayangan atau embun.',
    note: 'Kubah dan housing merupakan bentuk representatif. Spesifikasi spektral dan kelas instrumen bergantung pada tipe pyranometer.', position: [8, 0, 9], viewOffset: [3, 3, 4]
  },
  {
    id: 'barometer', name: 'Barometer Digital', shortName: 'Barometer', category: 'otomatis', categoryLabel: 'OTOMATIS', subtitle: 'Pengukuran tekanan atmosfer', parameter: ['Tekanan udara'],
    function: 'Mengukur tekanan udara setempat untuk pemantauan cuaca, analisis perubahan massa udara, dan sebagai variabel penting dalam pengamatan sinoptik.',
    principle: 'Sensor elektronik berbasis MEMS mengukur deformasi mikrostruktur akibat tekanan atmosfer. Sinyal sensor dikompensasi terhadap suhu dan dikonversi menjadi nilai tekanan.',
    components: ['Sensor tekanan MEMS', 'Enclosure pelindung', 'Ventilasi tekanan / port', 'Layar pembaca', 'Catu daya dan antarmuka data'],
    operation: 'Tempatkan sensor pada lingkungan terlindung dengan ventilasi tekanan yang sesuai, jauh dari panas lokal dan getaran. Lakukan koreksi elevasi dan kalibrasi sesuai kebutuhan jaringan pengamatan.',
    note: 'Barometer pada model ditampilkan sebagai unit digital dalam enclosure edukatif. Penempatan operasional bergantung pada desain stasiun dan standar yang digunakan.', position: [19, 0, -2], viewOffset: [3, 2, 4]
  }
];
