import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { CSS2DRenderer } from 'three/addons/renderers/CSS2DRenderer.js';
import { instruments } from './data/instruments.js';
import { createMeteorologicalGarden } from './components/MeteorologicalGarden.js';
import { setupLighting } from './systems/LightingSystem.js';
import { createCameraSystem } from './systems/CameraSystem.js';
import { createInteractionSystem } from './systems/InteractionSystem.js';
import './styles/main.css';

const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
const viewport = $('#viewport');
const mount = $('#three-root');
const scene = new THREE.Scene();
scene.background = new THREE.Color('#9fc5da');

const camera = new THREE.PerspectiveCamera(42, viewport.clientWidth / viewport.clientHeight, 0.1, 260);
camera.position.set(43,36,48);
const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:'high-performance', alpha:false});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(viewport.clientWidth, viewport.clientHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.04;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.domElement.setAttribute('aria-label','Model 3D taman alat meteorologi. Gunakan mouse untuk mengorbit dan memilih instrumen.');
mount.appendChild(renderer.domElement);

const labelRenderer = new CSS2DRenderer();
labelRenderer.setSize(viewport.clientWidth, viewport.clientHeight);
labelRenderer.domElement.className = 'label-renderer';
labelRenderer.domElement.setAttribute('aria-hidden','true');
mount.appendChild(labelRenderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.065;
controls.rotateSpeed = 0.56;
controls.zoomSpeed = 0.82;
controls.panSpeed = 0.7;
controls.minDistance = 8;
controls.maxDistance = 115;
controls.maxPolarAngle = Math.PI * 0.495;
controls.target.set(0,0,0);
controls.update();
setupLighting(scene);

const {objects, labels} = createMeteorologicalGarden(scene, labelRenderer.domElement);
const cameraSystem = createCameraSystem(camera, controls);
const interaction = createInteractionSystem({camera,scene,renderer,objects,onSelect:selectInstrument,onHover:hoverInstrument});

const grid = new THREE.GridHelper(64,32,'#e5f1f4','#d4e3e8');
grid.position.y = -0.135;
grid.material.transparent = true; grid.material.opacity = 0.26; grid.visible = false; scene.add(grid);

let selectedId = null;
let currentCategory = 'semua';
let searchValue = '';
let labelsVisible = true;
let lastFrame = performance.now();
let frameCount = 0;
let fpsStamp = performance.now();

function iconFor(category) {
  if (category === 'otomatis') return '<svg viewBox="0 0 24 24"><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1m8.6 8.6 2.1 2.1m0-12.8-2.1 2.1m-8.6 8.6-2.1 2.1"/><circle cx="12" cy="12" r="5"/></svg>';
  if (category === 'manual') return '<svg viewBox="0 0 24 24"><path d="M5 20V4h14v16M8 8h8M8 12h8M8 16h5"/></svg>';
  if (category === 'lainnya') return '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 4v16M4 12h16"/></svg>';
  return '<svg viewBox="0 0 24 24"><path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8m0-12.8L5.6 18.4"/></svg>';
}
function renderInstrumentList() {
  const list = $('#instrument-list');
  const filtered = instruments.filter(item => {
    const matchesCategory = currentCategory === 'semua' || item.category === currentCategory || (currentCategory === 'lainnya' && item.category === 'lainnya');
    const matchesSearch = `${item.name} ${item.shortName} ${item.parameter.join(' ')}`.toLowerCase().includes(searchValue);
    return matchesCategory && matchesSearch;
  });
  $('#instrument-count').textContent = String(filtered.length).padStart(2,'0');
  list.innerHTML = filtered.map((item,index) => `
    <div class="instrument-row ${selectedId===item.id?'selected':''} ${objects.get(item.id).visible?'':'muted'}" data-id="${item.id}">
      <button class="instrument-select" data-select="${item.id}" aria-label="Pilih ${item.name}">
        <span class="instrument-icon ${item.category}">${iconFor(item.category)}</span>
        <span class="instrument-copy"><strong>${item.shortName}</strong><small>${item.categoryLabel} <i>·</i> ${item.parameter[0]}</small></span>
        <span class="row-chevron">›</span>
      </button>
      <button class="visibility-button" data-visibility="${item.id}" aria-label="${objects.get(item.id).visible?'Sembunyikan':'Tampilkan'} ${item.name}" title="Tampilkan/sembunyikan">${objects.get(item.id).visible?eyeIcon():eyeOffIcon()}</button>
    </div>`).join('');
  list.querySelectorAll('[data-select]').forEach(button => button.addEventListener('click',()=>selectInstrument(button.dataset.select,true)));
  list.querySelectorAll('[data-visibility]').forEach(button => button.addEventListener('click',()=>toggleInstrument(button.dataset.visibility)));
}
function eyeIcon(){return '<svg viewBox="0 0 24 24"><path d="M2.5 12s3.4-6 9.5-6 9.5 6 9.5 6-3.4 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.6"/></svg>';}
function eyeOffIcon(){return '<svg viewBox="0 0 24 24"><path d="m3 3 18 18M10.6 6.2A9.8 9.8 0 0 1 12 6c6.1 0 9.5 6 9.5 6a15 15 0 0 1-3 3.5M6.2 6.3C3.8 7.8 2.5 12 2.5 12s3.4 6 9.5 6c1 0 1.9-.2 2.7-.5"/></svg>';}
function selectInstrument(id, focus=false) {
  const item = instruments.find(entry => entry.id === id); if(!item || !objects.get(id).visible) return;
  selectedId=id; interaction.setSelected(id);
  $('#info-empty').classList.add('hidden'); $('#info-content').classList.remove('hidden');
  $('#info-category').textContent=item.categoryLabel;
  $('#info-category').dataset.category=item.category;
  $('#info-index').textContent=`${String(instruments.findIndex(x=>x.id===id)+1).padStart(2,'0')} / ${String(instruments.length).padStart(2,'0')}`;
  $('#info-name').textContent=item.name;
  $('#info-subtitle').textContent=item.subtitle;
  $('#info-parameter').innerHTML=item.parameter.map(p=>`<span>${p}</span>`).join('');
  $('#info-function').textContent=item.function;
  $('#info-principle').textContent=item.principle;
  $('#info-components').innerHTML=item.components.map(component=>`<li>${component}</li>`).join('');
  $('#info-operation').textContent=item.operation;
  $('#info-note').textContent=item.note;
  renderInstrumentList();
  if(focus) cameraSystem.focus(objects.get(id),item.viewOffset);
}
function hoverInstrument(id) {
  const tooltip=$('#hover-tooltip');
  if(!id){tooltip.classList.remove('visible');return;}
  const item=instruments.find(entry=>entry.id===id); if(!item)return;
  tooltip.textContent=item.shortName; tooltip.classList.add('visible');
}
function toggleInstrument(id) {
  const obj=objects.get(id); if(!obj)return;
  obj.visible=!obj.visible;
  if(!obj.visible && selectedId===id){selectedId=null;interaction.setSelected(null);$('#info-content').classList.add('hidden');$('#info-empty').classList.remove('hidden');}
  renderInstrumentList();
}
function setLabels(visible) {
  labelsVisible=visible;
  labels.forEach(label=>{if(label.element)label.element.style.display=visible?'':'none';});
  $('#labels-switch').checked=visible; $('#labels-toggle').setAttribute('aria-pressed',String(visible));
}
function setGrid(visible) {grid.visible=visible;$('#grid-switch').checked=visible;$('#grid-toggle').setAttribute('aria-pressed',String(visible));}
function fullscreen() {
  if(!document.fullscreenElement){(viewport.requestFullscreen?.() || document.documentElement.requestFullscreen?.())?.catch?.(()=>{});} else document.exitFullscreen?.();
}

renderInstrumentList();
$('#instrument-search').addEventListener('input',e=>{searchValue=e.target.value.trim().toLowerCase();renderInstrumentList();});
$$('.category-tab').forEach(btn=>btn.addEventListener('click',()=>{$$('.category-tab').forEach(b=>b.classList.toggle('active',b===btn));currentCategory=btn.dataset.category;renderInstrumentList();}));
$$('.view-btn').forEach(btn=>btn.addEventListener('click',()=>{$$('.view-btn').forEach(b=>b.classList.toggle('active',b===btn));cameraSystem.preset(btn.dataset.view);}));
$('#reset-camera').addEventListener('click',()=>{cameraSystem.preset('isometric');$$('.view-btn').forEach(b=>b.classList.toggle('active',b.dataset.view==='isometric'));});
$('#focus-instrument').addEventListener('click',()=>{if(selectedId){const data=instruments.find(x=>x.id===selectedId);cameraSystem.focus(objects.get(selectedId),data.viewOffset);}});
$('#labels-switch').addEventListener('change',e=>setLabels(e.target.checked));
$('#labels-toggle').addEventListener('click',()=>setLabels(!labelsVisible));
$('#grid-switch').addEventListener('change',e=>setGrid(e.target.checked));
$('#grid-toggle').addEventListener('click',()=>setGrid(!grid.visible));
$('#show-all').addEventListener('click',()=>{objects.forEach(obj=>obj.visible=true);renderInstrumentList();});
$('#fullscreen-btn').addEventListener('click',fullscreen); $('#fullscreen-floating').addEventListener('click',fullscreen);
document.addEventListener('fullscreenchange',()=>{setTimeout(onResize,80);});
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.fullscreenElement)document.exitFullscreen();});

function onResize(){
  const width=viewport.clientWidth,height=viewport.clientHeight;
  camera.aspect=width/height;camera.updateProjectionMatrix();
  renderer.setSize(width,height);labelRenderer.setSize(width,height);
}
const resizeObserver=new ResizeObserver(onResize);resizeObserver.observe(viewport);

function animate(now){
  requestAnimationFrame(animate);
  const dt=Math.min((now-lastFrame)/1000,0.05);lastFrame=now;
  cameraSystem.update(now);controls.update();renderer.render(scene,camera);labelRenderer.render(scene,camera);
  frameCount++;
  if(now-fpsStamp>1300){$('#fps-value').textContent=`${Math.round(frameCount*1000/(now-fpsStamp))} FPS`;frameCount=0;fpsStamp=now;}
  if(document.visibilityState==='visible') $('#scene-status').textContent='RENDERING';
}
requestAnimationFrame(animate);
setLabels(true);
window.addEventListener('beforeunload',()=>{
  resizeObserver.disconnect();interaction.dispose();controls.dispose();
  scene.traverse(object=>{if(object.geometry)object.geometry.dispose();if(object.material){if(Array.isArray(object.material))object.material.forEach(m=>m.dispose());else object.material.dispose();}});
  renderer.dispose();labelRenderer.domElement.remove();
});
